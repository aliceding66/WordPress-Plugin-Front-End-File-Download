<?php
/*
Plugin Name: Frontend File Download
Plugin URI: http://cn.aliceding.com/wordpressplugins/frontendfd
Description: This plugin let the wordpress website visitors to download files at a specific post.  The administrator/editor can set up the file at backend at post editing page.  
Version: 1.1
Author:Alice Ding
Author URI: http://cn.aliceding.com
Requires at least: 3.9
Tested up to: 4.9.3
License: GPLv2
Tags: excel, fast, woo, woocommerce, wpsc, wp e-commerce, products, editor, spreadsheet, import, export 
*/
/*

Copyright (c) cn.aliceding.com

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

*/

global $wpdb;
define("addown",plugin_dir_path(__FILE__));

function addown_style() {
	echo'<link rel="stylesheet" href="'.plugin_dir_url( __FILE__ ).'css/style.css" type="text/css" />';
}
add_action('wp_head', 'addown_style');

function addown_show_down($content)
{
	if(is_single())
	{
		$addown_start=get_post_meta(get_the_ID(), 'addown_start', true);
		$addown_name=get_post_meta(get_the_ID(), 'addown_name', true);
		$addown_size=get_post_meta(get_the_ID(), 'addown_size', true);
		$addown_demourl=get_post_meta(get_the_ID(), 'addown_demourl', true);
		$addown_date=get_post_meta(get_the_ID(), 'addown_date', true);
		$addown_version=get_post_meta(get_the_ID(), 'addown_version', true);
		$addown_author=get_post_meta(get_the_ID(), 'addown_author', true);
		$addown_downurl1=get_post_meta(get_the_ID(), 'addown_downurl1', true);
		$addown_downurl2=get_post_meta(get_the_ID(), 'addown_downurl2', true);
		$addown_downurl3=get_post_meta(get_the_ID(), 'addown_downurl3', true);

		
		
		////File name, size, version, author info, latest update etc.
		if($addown_demourl)
		{
		$ad_content .= '<strong><a class="yanshibtn" rel="external nofollow" title="'.$addown_name.'" href="'.$addown_demourl.'"  target="_blank">Demo</a></strong>';
		
		}
		if($addown_start)
		{
			$content .= '<br />';
			$content .= '
			<div class="addown_down_link"><p><strong>File Information：</strong></p><p></p><p>File Name：'.$addown_name.'</p><p  style="position:relative;">File Size：'.$addown_size.'<span style="position:absolute;left:40%;">Version：'.$addown_version.'</span></p><p style="position:relative;">Latest Update：'.$addown_date.'<span style="position:absolute;left:40%;">Author Info：'.$addown_author.'</span></p><p class="downlink"><strong><a class="downbtn" rel="external nofollow" title="'.$addown_name.'" href="'.$addown_downurl1.'"  target="_blank">Download</a></strong> '.$ad_content.'</p><p></p></div>';
		}
	}

	return $content;
}
add_action('the_content','addown_show_down');
?>
<?php include('meta-box.php'); ?>